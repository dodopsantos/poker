-- CreateIndex
CREATE INDEX "TableSeat_userId_state_idx" ON "TableSeat"("userId", "state");
